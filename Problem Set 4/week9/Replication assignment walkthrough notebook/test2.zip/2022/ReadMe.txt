We strongly recommend all users read through the included documentation carefully for very important methodological changes in GSS this round. 

For reports of and updates on suspected issues in the GSS please visit https://gss.norc.org/Documents/other/Suspected%20Issues%20in%20the%20GSS.pdf 